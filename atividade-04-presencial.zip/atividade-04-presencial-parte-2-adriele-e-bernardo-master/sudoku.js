console.log('sudoku.js');
let spaces;
let matriz = [['', '', '', ''], ['', '', '', ''], ['', '', '', ''], ['', '', '', '']];
let array = [[[2, 4, 3, 1], [3, 1, 4, 2], [1, 3, 2, 4], [4, 2, 1, 3]], [[4, 1, 2, 3], [3, 2, 4, 1], [2, 3, 1, 4], [1, 4, 3, 2]], [[3, 4, 1, 2], [1, 2, 3, 4], [2, 1, 4, 3], [4, 3, 2, 1]], [[2, 1, 4, 3], [3, 4, 1, 2], [1, 2, 3, 4], [4, 3, 2, 1]]];
function generate(spaces, array) {
    let table = [['', '', '', ''], ['', '', '', ''], ['', '', '', ''], ['', '', '', '']]
    let filled = [];
    let raffle = Math.floor(Math.random() * (array.length));
    for (let y = 0; y < spaces; y++) {
        let file = Math.floor(Math.random() * 16);
        while (filled.indexOf(file) !== -1) {
            file = Math.floor(Math.random() * 16);
        }
        filled.push(file);
        table[Math.floor(file / 4)][(file % 4)] = array[raffle][Math.floor(file / 4)][(file % 4)];
    }
    return table;
}
const pieceofcake = document.body.children[0];
const letsrock = document.body.children[1];
const comegetsome = document.body.children[2];
const damnimgood = document.body.children[3];
function add(matriz) {
    let whr = [];
    for (let i = 0; i < 4; i++) {
        for (let k = 0; k < 4; k++) {
            if (matriz[i][k] !== '') {
                whr.push((i * 4) + k);
            }
        }
    }
    for (let u = 0; u < whr.length; u++) {
        document.body.children[4].querySelectorAll('td')[whr[u]].textContent = matriz[Math.floor((whr[u]) / 4)][(whr[u]) % 4]
    }
}
pieceofcake.addEventListener('click', function (e) {
    spaces = 2;
    let matriz = generate(spaces, array);
    add(matriz);
})
letsrock.addEventListener('click', function (e) {
    spaces = 4;
    let matriz = generate(spaces, array);
    add(matriz);
});
comegetsome.addEventListener('click', function (e) {
    spaces = 6;
    let matriz = generate(spaces, array);
    add(matriz);
});
damnimgood.addEventListener('click', function (e) {
    spaces = 8;
    let matriz = generate(spaces, array);
    add(matriz);
});
let td = document.body.children[4].querySelectorAll('td');
for (let i = 0; i < td.length; i++) {
    let usd = [];
    let number = 0;
    td[i].addEventListener('wheel', function (e) { //trocar pra wheel
        let y = document.body.children[4].querySelectorAll('td')[i];
        let recv;
        let change = false;
        if (document.body.children[4].querySelectorAll('td')[i].textContent === '') {
            usd.push(i);
        };
        if (usd.indexOf(i) !== -1) {
            change = true;
        } else {
            change = false;
        }
        if (change === true) {
            number++
            if (number % 5 !== 0) {
                y.textContent = (number % 5);
                recv = number % 5;
            } else {
                y.textContent = '';
                recv = '';
            }
            if (i <= 3) {
                matriz[0][i % 4] = recv;
            }
            if (i >= 4 && i <= 7) {
                matriz[1][i % 4] = recv;
            }
            if (i >= 8 && i <= 11) {
                matriz[2][i % 4] = recv;
            }
            if (i >= 12 && i <= 15) {
                matriz[3][i % 4] = recv;
            }
        } 
    })
}
const checkk = document.body.children[5];
checkk.addEventListener('click', function (e) {
    let matriz = [['', '', '', ''], ['', '', '', ''], ['', '', '', ''], ['', '', '', '']]
    for (let i = 0; i < td.length; i++) {
        matriz[Math.floor(i / 4)][i % 4] = document.body.querySelectorAll('td')[i].innerHTML;
    }
    let error = false;
    for (let w = 0; w < 4; w++) {
        let apprt = [];
        for (let h = 0; h < 4; h++) {
            apprt.push(matriz[h][w]);
        }
        apprt = apprt.sort();
        for (let i = 0; i < 4; i++) {
            if (apprt[i] !== ((i + 1).toString())) {
                error = true;
            }
        }
    }
    for (let k = 0; k < 4; k++) {
        let apprtt = [];
        for (let c = 0; c < 4; c++) {
            apprtt.push(matriz[k][c]);
        }
        apprtt.sort()
        for (let m = 0; m < 4; m++) {
            if (apprtt[m] != (m + 1).toString()) {
                error = true;
            }
        }
    }
    for (let j = 0; j < 4; (j = j + 2)) {
        let shwup = [];
        for (let n = 0; n < 2; (n = n + 2)) {
            shwup.push(matriz[j][n]);
            shwup.push(matriz[j + 1][n]);
            shwup.push(matriz[j][n + 1]);
            shwup.push(matriz[j + 1][n + 1]);
        }
        shwup.sort()
        for (let t = 0; t < 4; t++) {
            if (shwup[t] != (t + 1).toString()) {
                error = true;
            }
        }
    }
    if (error === false) {
        document.body.children[6].textContent = 'Parabéns, você ganhou :)';
    } else if (error === true) {
        document.body.children[6].textContent = 'Algo está errado :(';
    }
})
